function [ S ] = S(M,A)
    S = M * A;
end